# Bossa Asado i Mar AI Operations Hub - Deployment Guide

## 🚀 Live Website URLs

**Frontend (React):** https://ntsroauh.manus.space  
**Backend (Flask API):** https://9yhyi3cq0opl.manus.space

## 📁 Project Structure

```
bossa-ai-website/          # React Frontend
├── src/
│   ├── App.jsx           # Main application component
│   ├── api/
│   │   └── BossaAPI.js   # API utility functions
│   └── components/       # UI components
├── dist/                 # Built production files
└── package.json

bossa-ai-backend/          # Flask Backend
├── src/
│   ├── main.py          # Main Flask application
│   └── routes/
│       └── agents.py    # API routes for agents
├── requirements.txt     # Python dependencies
└── venv/               # Virtual environment
```

## 🔧 Local Development Setup

### Backend (Flask)
```bash
cd bossa-ai-backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```
Backend will run on: http://localhost:5000

### Frontend (React)
```bash
cd bossa-ai-website
npm install
npm run dev
```
Frontend will run on: http://localhost:5173

## 🌐 Permanent Deployment Options

### Option 1: Vercel (Recommended for Frontend)
1. Connect your GitHub repository to Vercel
2. Set build command: `npm run build`
3. Set output directory: `dist`
4. Update API_BASE_URL in `src/api/BossaAPI.js` to your backend URL

### Option 2: Netlify (Alternative for Frontend)
1. Connect your GitHub repository to Netlify
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Update API_BASE_URL in `src/api/BossaAPI.js` to your backend URL

### Option 3: Heroku (For Backend)
1. Create a Heroku app
2. Add a `Procfile` with: `web: python src/main.py`
3. Set environment variables if needed
4. Deploy via Git or GitHub integration

### Option 4: Railway (Full-Stack)
1. Connect your GitHub repository
2. Railway will auto-detect both React and Flask
3. Configure environment variables
4. Deploy both frontend and backend

## 🔑 Environment Variables

### Frontend (.env)
```
VITE_API_BASE_URL=https://your-backend-domain.com/api
```

### Backend (.env)
```
FLASK_ENV=production
CORS_ORIGINS=https://your-frontend-domain.com
```

## 📋 Features Implemented

### Frontend Features
- ✅ Responsive design with Tailwind CSS
- ✅ Modern UI components with shadcn/ui
- ✅ Bilingual support (English & Papiamentu)
- ✅ Interactive agent cards
- ✅ Dashboard overview
- ✅ API integration ready
- ✅ Professional branding for Bossa Asado i Mar

### Backend Features
- ✅ Flask REST API
- ✅ CORS enabled for cross-origin requests
- ✅ 18 AI agents data structure
- ✅ Health check endpoint
- ✅ Agent interaction endpoints
- ✅ Dashboard data endpoints
- ✅ Modular route structure

### AI Agents Included
1. **FireChefGPT** - Menu, grilling, recipe, plating
2. **SmartInventoryGPT** - Inventory, stock, forecasting
3. **ServiceFlowGPT** - Reservations, guest flow, table planning
4. **FinanceGPT** - Budget, cost, revenue, profit
5. **MarketingGPT** - Campaign, social media, promo
6. **CustomerCareGPT** - FAQ, complaint handling, upsell
7. **TrainingGPT** - Staff training, onboarding, quiz
8. **EventPlannerGPT** - Event design, timeline, VIP
9. **AnalyticsGPT** - Reporting, dashboard, KPIs
10. **SourBarGPT** - Bar menu, cocktails, pairings
11. **ContentStudioGPT** - Video, photo, blog, social content
12. **LoyaltyGPT** - VIP program, loyalty, perks
13. **SustainabilityGPT** - Green strategy, waste, eco-supplier
14. **SupplierGPT** - Supplier contact, negotiation, quotes
15. **BossVisionGPT** - Orchestration, dashboard, agent control
16. **PromptCrafter** - Prompt generator, creative AI prompts
17. **YouTubeGPT** - YouTube/video strategy, script, title
18. **BossaAsadoiMarGPT** - Universal onboarding, AI suite explainer

## 🎨 Branding & Design

- **Primary Colors:** Orange (#f97316), Red (#dc2626)
- **Restaurant Theme:** Fire-grill, Curaçao, Caribbean
- **Typography:** Modern, clean, professional
- **Icons:** Lucide React icons
- **Layout:** Responsive grid, card-based design

## 🔧 Customization Guide

### Adding New Agents
1. Update `agents.py` in backend with new agent data
2. Add new icon to `agentIcons` object in `App.jsx`
3. Add new color to `agentColors` object in `App.jsx`
4. Update agent count in health check

### Modifying Branding
1. Update colors in `App.jsx` and Tailwind classes
2. Replace logo/icon in header section
3. Update restaurant information in footer
4. Modify meta tags in `index.html`

### Adding New Features
1. Create new API endpoints in `routes/agents.py`
2. Add corresponding frontend components
3. Update API utility functions in `BossaAPI.js`
4. Test locally before deployment

## 🚨 Important Notes

- The current deployment uses temporary sandbox URLs
- For production, you'll need to deploy to your own hosting platform
- Update API URLs in the frontend when deploying to production
- Ensure CORS is properly configured for your domain
- Consider adding authentication for production use
- Monitor API usage and implement rate limiting if needed

## 📞 Support

For technical support or customization requests, refer to the Bossa Asado i Mar AI Operations documentation or contact your development team.

---

**Masha danki pa usa Bossa Asado i Mar AI Operations Hub!**  
**Thank you for using Bossa Asado i Mar AI Operations Hub!**

